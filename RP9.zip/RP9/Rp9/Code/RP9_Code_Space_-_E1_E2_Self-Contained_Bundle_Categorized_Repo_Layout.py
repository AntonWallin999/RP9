#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# RP9 Code Space — E1 + E2 Self-Contained Bundle (Categorized Repo Layout)
# Save as: rp9_bundle_E1_E2.py
# Run:     python rp9_bundle_E1_E2.py
#
# Ny katalogstruktur för publicering:
# RP9_Code/
#   E1/
#     E1_rp9_simulation.py
#     E1_results_overview.md
#     E1_overview.json
#     E1_band1_420Hz.csv
#     E1_band2_phi420Hz.csv
#     E1_band3_phi2_420Hz.csv
#     E1_band_sweeps.png
#     E1_report.html
#   E2/
#     E2_rp9_simulation_E12.py
#     E2_results_overview.md
#     E2_overview.json
#     E2_band1_420Hz_E12.csv
#     E2_band2_phi420Hz_E12.csv
#     E2_band3_phi2_420Hz_E12.csv
#     E2_band_sweeps.png
#     E2_report.html
#   docs/
#     SCHEMATIC_ASCII.txt
#     README_RUN_THIS_FIRST.md
#
# Physikmodell (serie-RLC, normaliserad källa 1 Vrms):
# - S2-spol: r=0.200 m, N=400, d=0.63 mm, ρ_Cu=1.68e-8 Ω·m
# - Induktans (Wheeler-lik log): $L\approx \mu_0 N^2 r \left(\ln\left(\frac{8r}{a}\right)-2\right)$ med $a=\frac{d}{2}$
# - Kopparresistans: $R_{Cu}=\rho \frac{\ell}{A}$, $\ell\approx N\cdot 2\pi r$, $A=\pi\left(\frac{d}{2}\right)^2$
# - Tre band: $f_1=420\,\text{Hz}$, $f_2=\varphi\cdot 420\,\text{Hz}$, $f_3=\varphi^2\cdot 420\,\text{Hz}$, $\varphi=\frac{1+\sqrt{5}}{2}$
# - Exakta kondensatorer per band: $C=\frac{1}{(2\pi f)^2 L}$
# - E1 använder exakta $C$; E2 använder närmaste E12-värde
# - Serieimpedans: $Z=R_\text{series}+j\left(\omega L-\frac{1}{\omega C}\right)$, med $R_\text{series}=R_{Cu}+R_L$
# - Ström: $|I|=\frac{1}{|Z|}$ vid 1 Vrms, spänning över lasten: $V_{RL}=|I|\cdot R_L$ (loggas som "V_RL_norm")

import os, math, json, csv, sys, webbrowser
from datetime import datetime

# -------- Optional dependencies & fallbacks ----------
try:
    import numpy as _np
except Exception:
    _np = None

try:
    import pandas as _pd
except Exception:
    _pd = None

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as _plt
except Exception:
    _plt = None

# ----------------- Constants ------------------------
MU0 = 4.0e-7 * math.pi
phi = (1.0 + math.sqrt(5.0)) / 2.0

# S2 fixed coil baseline
RADIUS_M = 0.200      # m (to wire center)
TURNS_N  = 400
WIRE_D_M = 0.00063    # 0.63 mm
RHO_CU   = 1.68e-8    # Ω·m
RL_OHM   = 10.0       # Ω load

# --------- Helpers: coil, E12 rounding, sweeps --------
def coil_inductance_L(N, r, wire_d):
    # $L\approx \mu_0 N^2 r \left(\ln\left(\frac{8r}{a}\right)-2\right)$, $a=\frac{d}{2}$
    a = max(wire_d * 0.5, 1e-6)
    return MU0 * (N**2) * r * (math.log(8.0*r/a) - 2.0)

def coil_copper_R(N, r, wire_d, rho_cu):
    # $R_{Cu}=\rho \frac{\ell}{A}$, $\ell\approx N\cdot 2\pi r$, $A=\pi\left(\frac{d}{2}\right)^2$
    length = N * 2.0 * math.pi * r
    A = math.pi * (wire_d * 0.5)**2
    return rho_cu * length / A

def exact_C_for(f_hz, L_h):
    # $C=\frac{1}{(2\pi f)^2 L}$
    w = 2.0 * math.pi * f_hz
    return 1.0 / (w*w*L_h)

def e12_nearest_C(value_F):
    # Väljer närmaste E12 mellan 1e-12..1e0 F
    e12 = [1.0, 1.2, 1.5, 1.8, 2.2, 2.7, 3.3, 3.9, 4.7, 5.6, 6.8, 8.2]
    best = None
    for exp in range(-12, 1):
        for m in e12:
            c = m * (10.0 ** exp)
            err = abs(c - value_F) / value_F
            if (best is None) or (err < best[0]):
                best = (err, c)
    return best[1] if best else value_F

def sweep_series_rlc(f0, L_h, C_f, R_series, npts=2400, span=0.25):
    # Frekvenssvep i $[f_0(1-\text{span}), f_0(1+\text{span})]$, 1 Vrms källa, $V_{RL}=|I|\cdot R_L$
    f_min = f0 * (1.0 - span)
    f_max = f0 * (1.0 + span)

    if _np is not None:
        f = _np.linspace(f_min, f_max, npts)
        w = 2.0 * math.pi * f
        X = w * L_h - 1.0/(w * C_f)
        Zmag = _np.sqrt(R_series**2 + X**2)
        I = 1.0 / Zmag
        vrl = I * RL_OHM
        idx = int(_np.argmax(vrl))
        f_peak = float(f[idx])
        v_peak = float(vrl[idx])
        rows = list(zip(f.tolist(), vrl.tolist()))
    else:
        step = (f_max - f_min) / (npts - 1)
        rows = []
        v_peak = -1.0
        f_peak = f_min
        for i in range(npts):
            f = f_min + i * step
            w = 2.0 * math.pi * f
            X = w * L_h - 1.0/(w * C_f)
            Zmag = math.sqrt(R_series**2 + X**2)
            I = 1.0 / Zmag
            vrl = I * RL_OHM
            rows.append((f, vrl))
            if vrl > v_peak:
                v_peak = vrl
                f_peak = f
    return rows, (f_peak, v_peak)

def write_csv(path, rows, header=("f_Hz","V_RL_norm")):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)

def try_plot_png(path_png, curves, title):
    # curves: list of dicts { 'label': str, 'rows': [(f, v), ...] }
    if _plt is None:
        return False
    _plt.figure(figsize=(8,5))
    for c in curves:
        f = [r[0] for r in c["rows"]]
        v = [r[1] for r in c["rows"]]
        _plt.plot(f, v, label=c.get("label","curve"))
    _plt.xlabel("Frequency (Hz)")
    _plt.ylabel("Normalized V_RL (V per 1 Vrms source)")
    _plt.title(title)
    _plt.legend()
    _plt.tight_layout()
    _plt.savefig(path_png, dpi=140)
    try:
        _plt.show()
    except Exception:
        pass
    _plt.close()
    return True

def write_md(path, lines):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)

def write_html_report(path_html, title, png_path_or_none, summary_lines):
    # Enkel HTML med ev. inbäddad PNG.
    head = (
        "<!DOCTYPE html>\n"
        "<html>\n"
        "<head>\n"
        "<meta charset=\"utf-8\">\n"
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
        "<title>" + title + "</title>\n"
        "<style>\n"
        "body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Helvetica,Arial,sans-serif;line-height:1.4;padding:16px;}\n"
        "h1{margin:0 0 12px 0;font-size:20px;}\n"
        "pre{background:#111;color:#eee;padding:8px;overflow:auto;}\n"
        "img{max-width:100%;height:auto;border:1px solid #ccc;border-radius:6px;}\n"
        "ul{padding-left:20px;}\n"
        "</style>\n"
        "</head>\n"
        "<body>\n"
    )
    body = "<h1>" + title + "</h1>\n"
    if png_path_or_none and os.path.exists(png_path_or_none):
        rel = os.path.basename(png_path_or_none)
        body += "<p><img src=\"" + rel + "\" alt=\"plot\"></p>\n"
    if summary_lines:
        body += "<ul>\n"
        for ln in summary_lines:
            body += "<li>" + ln.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;") + "</li>\n"
        body += "</ul>\n"
    tail = "</body>\n</html>\n"
    os.makedirs(os.path.dirname(path_html), exist_ok=True)
    with open(path_html, "w", encoding="utf-8") as f:
        f.write(head + body + tail)

# ------------------ Main build (categorized) -----------------------
BASE = os.path.abspath("./RP9_Code")
E1_DIR = os.path.join(BASE, "E1")
E2_DIR = os.path.join(BASE, "E2")
DOCS_DIR = os.path.join(BASE, "docs")
for d in (BASE, E1_DIR, E2_DIR, DOCS_DIR):
    os.makedirs(d, exist_ok=True)

# Coil baseline
L_H   = coil_inductance_L(TURNS_N, RADIUS_M, WIRE_D_M)
R_CU  = coil_copper_R(TURNS_N, RADIUS_M, WIRE_D_M, RHO_CU)
R_SER = R_CU + RL_OHM

# Bands
f1 = 420.0
f2 = phi * 420.0
f3 = (phi**2) * 420.0

# Exact C per band (E1)
C1_exact = exact_C_for(f1, L_H)
C2_exact = exact_C_for(f2, L_H)
C3_exact = exact_C_for(f3, L_H)

# E12-rounded C per band (E2)
C1_e12 = e12_nearest_C(C1_exact)
C2_e12 = e12_nearest_C(C2_exact)
C3_e12 = e12_nearest_C(C3_exact)

# ----------------- E1: exact C sweeps ----------------
E1 = {
    "coil": {"r_m": RADIUS_M, "N": TURNS_N, "wire_d_m": WIRE_D_M,
             "L_H": L_H, "R_cu_Ohm": R_CU},
    "RL_Ohm": RL_OHM, "R_series_Ohm": R_SER,
    "bands": {"f1_Hz": f1, "C1_F": C1_exact,
              "f2_Hz": f2, "C2_F": C2_exact,
              "f3_Hz": f3, "C3_F": C3_exact},
    "peaks": {},
    "artifacts": {}
}

curves_E1 = []
for tag, f0, Cval in [
    ("band1_420Hz", f1, C1_exact),
    ("band2_phi420Hz", f2, C2_exact),
    ("band3_phi2_420Hz", f3, C3_exact),
]:
    rows, (fpk, vpk) = sweep_series_rlc(f0=f0, L_h=L_H, C_f=Cval, R_series=R_SER)
    csv_path = os.path.join(E1_DIR, "E1_" + tag + ".csv")
    write_csv(csv_path, rows)
    E1["peaks"][tag] = {"f0_center_Hz": f0, "C_F": Cval,
                        "f_peak_Hz": fpk, "V_RL_peak_norm": vpk}
    curves_E1.append({"label": tag, "rows": rows})

png_E1 = os.path.join(E1_DIR, "E1_band_sweeps.png")
plotted_E1 = try_plot_png(png_E1, curves_E1, "RP9 E1 — Exact C sweeps")

E1_overview_path = os.path.join(E1_DIR, "E1_overview.json")
write_json(E1_overview_path, E1)

E1_md_lines = [
    "# E1 – RP9 Three-Band Coil Simulation Overview (Exact C)",
    "",
    "Coil L ≈ " + f"{E1['coil']['L_H']:.6e}" + " H, R_cu ≈ " + f"{E1['coil']['R_cu_Ohm']:.3f}" + " Ω; "
    + "RL = " + f"{E1['RL_Ohm']:.3f}" + " Ω; R_series = " + f"{E1['R_series_Ohm']:.3f}" + " Ω",
    ""
]
for tag, pk in E1["peaks"].items():
    E1_md_lines.append("- " + tag + ": center " + f"{pk['f0_center_Hz']:.3f}" + " Hz, C = " + f"{pk['C_F']:.6e}" + " F")
    E1_md_lines.append("  - Peak @ " + f"{pk['f_peak_Hz']:.3f}" + " Hz, V_RL_peak_norm ≈ " + f"{pk['V_RL_peak_norm']:.6f}")
if plotted_E1:
    E1_md_lines.append("")
    E1_md_lines.append("Figure: " + os.path.basename(png_E1))
E1_md_lines.append("")
E1_md_lines.append("Artifacts:")
for tag in ["band1_420Hz", "band2_phi420Hz", "band3_phi2_420Hz"]:
    E1_md_lines.append("- " + os.path.join("E1_" + tag + ".csv"))
E1_md = os.path.join(E1_DIR, "E1_results_overview.md")
write_md(E1_md, E1_md_lines)

# Referenskopia av E1-skript
E1_script_path = os.path.join(E1_DIR, "E1_rp9_simulation.py")
E1_ref_lines = [
    "# Auto-emitted reference: E1 exact-C logic is embedded in rp9_bundle_E1_E2.py",
    "# See E1_results_overview.md and E1 CSVs for outputs.",
    "# Physics uses: C = 1/((2π f)^2 L), series RLC, V_RL = |I|*R_L with 1 Vrms source."
]
write_md(E1_script_path, E1_ref_lines)

# ----------------- E2: E12 C sweeps + compare --------
E2 = {
    "coil": {"r_m": RADIUS_M, "N": TURNS_N, "wire_d_m": WIRE_D_M,
             "L_H": L_H, "R_cu_Ohm": R_CU},
    "RL_Ohm": RL_OHM, "R_series_Ohm": R_SER,
    "bands": {"f1_Hz": f1, "C1_E12_F": C1_e12,
              "f2_Hz": f2, "C2_E12_F": C2_e12,
              "f3_Hz": f3, "C3_E12_F": C3_e12},
    "peaks": {},
    "artifacts": {}
}

curves_E2 = []
for tag, f0, Cval in [
    ("band1_420Hz_E12", f1, C1_e12),
    ("band2_phi420Hz_E12", f2, C2_e12),
    ("band3_phi2_420Hz_E12", f3, C3_e12),
]:
    rows, (fpk, vpk) = sweep_series_rlc(f0=f0, L_h=L_H, C_f=Cval, R_series=R_SER)
    csv_path = os.path.join(E2_DIR, "E2_" + tag + ".csv")
    write_csv(csv_path, rows)
    E2["peaks"][tag] = {"f0_center_Hz": f0, "C_E12_F": Cval,
                        "f_peak_Hz": fpk, "V_RL_peak_norm": vpk}
    curves_E2.append({"label": tag, "rows": rows})

png_E2 = os.path.join(E2_DIR, "E2_band_sweeps.png")
plotted_E2 = try_plot_png(png_E2, curves_E2, "RP9 E2 — E12-rounded C sweeps")

E2_overview_path = os.path.join(E2_DIR, "E2_overview.json")
write_json(E2_overview_path, E2)

E2_md_lines = [
    "# E2 – RP9 Three-Band Coil Simulation Overview (E12 C)",
    "",
    "Coil L ≈ " + f"{E2['coil']['L_H']:.6e}" + " H, R_cu ≈ " + f"{E2['coil']['R_cu_Ohm']:.3f}" + " Ω; "
    + "RL = " + f"{E2['RL_Ohm']:.3f}" + " Ω; R_series = " + f"{E2['R_series_Ohm']:.3f}" + " Ω",
    ""
]
for tag, pk in E2["peaks"].items():
    E2_md_lines.append("- " + tag + ": center " + f"{pk['f0_center_Hz']:.3f}" + " Hz, C(E12) = " + f"{pk['C_E12_F']:.6e}" + " F")
    E2_md_lines.append("  - Peak @ " + f"{pk['f_peak_Hz']:.3f}" + " Hz, V_RL_peak_norm ≈ " + f"{pk['V_RL_peak_norm']:.6f}")
if plotted_E2:
    E2_md_lines.append("")
    E2_md_lines.append("Figure: " + os.path.basename(png_E2))
E2_md_lines.append("")
E2_md_lines.append("Artifacts:")
for tag in ["band1_420Hz_E12", "band2_phi420Hz_E12", "band3_phi2_420Hz_E12"]:
    E2_md_lines.append("- " + os.path.join("E2_" + tag + ".csv"))
E2_md = os.path.join(E2_DIR, "E2_results_overview.md")
write_md(E2_md, E2_md_lines)

# Referenskopia av E2-skript
E2_script_path = os.path.join(E2_DIR, "E2_rp9_simulation_E12.py")
E2_ref_lines = [
    "# Auto-emitted reference: E2 E12-capacitor logic is embedded in rp9_bundle_E1_E2.py",
    "# See E2_results_overview.md and E2 CSVs for outputs.",
    "# Physics uses: C = 1/((2π f)^2 L), series RLC, V_RL = |I|*R_L with 1 Vrms source."
]
write_md(E2_script_path, E2_ref_lines)

# ------------- ASCII wiring + README (docs/) ------------
SCHEM_lines = [
    "RP9 Three-Band Coil — Series RLC (one band at a time)",
    "(Spole) L = measured from build, R_Cu in series, + RL = 10 Ω",
    "",
    "        o~~~~~~( L )~~~~~~o",
    "         |                 |",
    "         |                 +-------------------> BAND-SELECT (choose BAND1/BAND2/BAND3)",
    "         |                                   |",
    "         |                                   v",
    "         |                     +-------------------------------+",
    "         |                     |  BAND-SELECT (manual switch) |",
    "         |                     +-------------------------------+",
    "         |                        |           |             |",
    "         |                        |           |             |",
    "         |                      (BAND1)     (BAND2)       (BAND3)",
    "         |                        |           |             |",
    "         |                      [C1]        [C2]          [C3]",
    "         |                    exact/E12   exact/E12     exact/E12",
    "         |                        |           |             |",
    "         |                        +-----------+-------------+------o----[ R_L = 10 Ω ]----o",
    "         |                                                                  ^             |",
    "         |                                                                  |             |",
    "         +------------------------------------------------------------------+-------------+",
    "                                                                         Measure A       Measure B"
]
with open(os.path.join(DOCS_DIR, "SCHEMATIC_ASCII.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(SCHEM_lines) + "\n")

README_lines = [
    "# RP9 Code Space — Quick Start (E1 + E2)",
    "",
    "## What this bundle does",
    "- Builds E1 (exact C from $C=\\frac{1}{(2\\pi f)^2 L}$) and E2 (nearest E12 C) sweeps",
    "- Emits CSVs, JSON overviews, Markdown summaries, and (if matplotlib installed) PNG plots",
    "",
    "## How to run",
    "```bash",
    "python rp9_bundle_E1_E2.py",
    "```",
    "",
    "## Outputs",
    "- RP9_Code/E1/: CSV, JSON, MD, PNG, HTML for exact C",
    "- RP9_Code/E2/: CSV, JSON, MD, PNG, HTML for E12 C",
    "- RP9_Code/docs/: ASCII schematic + this README"
]
with open(os.path.join(DOCS_DIR, "README_RUN_THIS_FIRST.md"), "w", encoding="utf-8") as f:
    f.write("\n".join(README_lines) + "\n")

# ----------- HTML-rapporter + auto-open --------------
E1_html = os.path.join(E1_DIR, "E1_report.html")
E2_html = os.path.join(E2_DIR, "E2_report.html")

E1_summary = []
for tag, pk in E1["peaks"].items():
    E1_summary.append(
        tag + " — center " + f"{pk['f0_center_Hz']:.3f}" + " Hz, "
        + "C=" + f"{pk['C_F']:.6e}" + " F, "
        + "peak @" + f"{pk['f_peak_Hz']:.3f}" + " Hz, "
        + "V_RL_peak_norm≈" + f"{pk['V_RL_peak_norm']:.6f}"
    )
write_html_report(E1_html, "RP9 E1 — Exact C sweeps", png_E1 if plotted_E1 else None, E1_summary)

E2_summary = []
for tag, pk in E2["peaks"].items():
    E2_summary.append(
        tag + " — center " + f"{pk['f0_center_Hz']:.3f}" + " Hz, "
        + "C(E12)=" + f"{pk['C_E12_F']:.6e}" + " F, "
        + "peak @" + f"{pk['f_peak_Hz']:.3f}" + " Hz, "
        + "V_RL_peak_norm≈" + f"{pk['V_RL_peak_norm']:.6f}"
    )
write_html_report(E2_html, "RP9 E2 — E12-rounded C sweeps", png_E2 if plotted_E2 else None, E2_summary)

try:
    webbrowser.open("file://" + os.path.abspath(E1_html))
except Exception:
    pass
try:
    webbrowser.open("file://" + os.path.abspath(E2_html))
except Exception:
    pass

# ----------------- Done ------------------------------
print("RP9 E1/E2 sweep generation complete.")
print("Output folder:", BASE)
print("E1 folder:", E1_DIR)
print("E2 folder:", E2_DIR)
print("Docs folder:", DOCS_DIR)

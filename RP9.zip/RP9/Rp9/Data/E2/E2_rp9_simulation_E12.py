# Auto-emitted reference: E2 E12-capacitor logic is embedded in rp9_bundle_E1_E2.py
# See E2_results_overview.md and E2 CSVs for outputs.
# Physics uses: C = 1/((2π f)^2 L), series RLC, V_RL = |I|*R_L with 1 Vrms source.

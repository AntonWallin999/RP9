# E2

_Index updated: 2025-09-02T00:32:30_

## Documents
- [E2_results_overview.md](E2_results_overview.md)

## Other files
- E2_band1_420Hz_E12.csv
- E2_band2_phi420Hz_E12.csv
- E2_band3_phi2_420Hz_E12.csv
- E2_band_sweeps.png
- E2_overview.json
- E2_report.html
- E2_rp9_simulation_E12.py


# E2 – RP9 Three-Band Coil Simulation Overview (E12 C)

Coil L ≈ 2.627052e-01 H, R_cu ≈ 27.090 Ω; RL = 10.000 Ω; R_series = 37.090 Ω

- band1_420Hz_E12: center 420.000 Hz, C(E12) = 5.600000e-07 F
  - Peak @ 414.967 Hz, V_RL_peak_norm ≈ 0.269614
- band2_phi420Hz_E12: center 679.574 Hz, C(E12) = 2.200000e-07 F
  - Peak @ 662.082 Hz, V_RL_peak_norm ≈ 0.269611
- band3_phi2_420Hz_E12: center 1099.574 Hz, C(E12) = 8.200000e-08 F
  - Peak @ 1084.334 Hz, V_RL_peak_norm ≈ 0.269613

Figure: E2_band_sweeps.png

Artifacts:
- E2_band1_420Hz_E12.csv
- E2_band2_phi420Hz_E12.csv
- E2_band3_phi2_420Hz_E12.csv

# RP9 Code Space — Quick Start (E1 + E2)

## What this bundle does
- Builds E1 (exact C from $C=\frac{1}{(2\pi f)^2 L}$) and E2 (nearest E12 C) sweeps
- Emits CSVs, JSON overviews, Markdown summaries, and (if matplotlib installed) PNG plots

## How to run
```bash
python rp9_bundle_E1_E2.py
```

## Outputs
- RP9_Code/E1/: CSV, JSON, MD, PNG, HTML for exact C
- RP9_Code/E2/: CSV, JSON, MD, PNG, HTML for E12 C
- RP9_Code/docs/: ASCII schematic + this README

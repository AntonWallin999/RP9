# Docs

_Index updated: 2025-09-02T00:32:30_

## Documents
- [README_RUN_THIS_FIRST.md](README_RUN_THIS_FIRST.md)

## Other files
- SCHEMATIC_ASCII.txt


# E1 – RP9 Three-Band Coil Simulation Overview (Exact C)

Coil L ≈ 2.627052e-01 H, R_cu ≈ 27.090 Ω; RL = 10.000 Ω; R_series = 37.090 Ω

- band1_420Hz: center 420.000 Hz, C = 5.466043e-07 F
  - Peak @ 420.044 Hz, V_RL_peak_norm ≈ 0.269613
- band2_phi420Hz: center 679.574 Hz, C = 2.087843e-07 F
  - Peak @ 679.645 Hz, V_RL_peak_norm ≈ 0.269609
- band3_phi2_420Hz: center 1099.574 Hz, C = 7.974850e-08 F
  - Peak @ 1099.689 Hz, V_RL_peak_norm ≈ 0.269601

Figure: E1_band_sweeps.png

Artifacts:
- E1_band1_420Hz.csv
- E1_band2_phi420Hz.csv
- E1_band3_phi2_420Hz.csv

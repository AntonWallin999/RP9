# Auto-emitted reference: E1 exact-C logic is embedded in rp9_bundle_E1_E2.py
# See E1_results_overview.md and E1 CSVs for outputs.
# Physics uses: C = 1/((2π f)^2 L), series RLC, V_RL = |I|*R_L with 1 Vrms source.

# E1

_Index updated: 2025-09-02T00:32:30_

## Documents
- [E1_results_overview.md](E1_results_overview.md)

## Other files
- E1_band1_420Hz.csv
- E1_band2_phi420Hz.csv
- E1_band3_phi2_420Hz.csv
- E1_band_sweeps.png
- E1_overview.json
- E1_report.html
- E1_rp9_simulation.py


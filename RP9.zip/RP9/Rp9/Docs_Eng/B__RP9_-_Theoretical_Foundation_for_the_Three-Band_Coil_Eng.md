\# RP9 – Theoretical Foundation for the Three-Band Coil    
Anton Wallin – Resonance Point 9 (2025)

\---

\#\# 1\. Core Principle  
RP9 is based on the idea that energy is not created, but released from the tension between two incompatible motions:    
\- \*\*Linear motion\*\* (time, translation, expansion)    
\- \*\*Circular motion\*\* (rotation, recurrence, resonance)  

When these meet in perfect symmetry, there is no net effect. But when symmetry is broken, \*\*friction in the field\*\* arises – not mechanical friction, but a vectorial imbalance that produces circulation.  

This circulation can be captured by a coil. Thus, RP9 is not a “generator” in the classical sense, but a \*\*geometric extractor of latent field energy\*\*.

\---

\#\# 2\. Asymmetry as an Energy Source  
\- Two pyramids aligned → perfect mirror → balance → no energy release.    
\- A third pyramid, rotated 9–15° → the system cannot return to equilibrium.    
\- The field is “forced” to circulate in an attempt to close a loop that cannot be closed.  

This is the \*\*RP9 point\*\*: a permanent dissonance that generates continuous motion.  

\---

\#\# 3\. Nature of the Friction  
The friction is not a mechanical collision but a \*\*meta-level difference\*\*:    
\- Linear motion tends toward infinite forward expansion.    
\- Circular motion tends to return to the same point.    
\- When combined in a structure where they never fully meet (φ vs √2), a “gap” arises – a residual energy.  

This residual energy manifests as current in the coil.

\---

\#\# 4\. Resonance Bands  
To stabilize the phenomenon, three bands are used:  
\- f₁ \= 420 Hz (base)    
\- f₂ \= φ·420 Hz ≈ 680 Hz    
\- f₃ \= φ²·420 Hz ≈ 1100 Hz  

Each band is a “projection” of the same RP9 principle at different levels.    
When combined, the bands create an additive and stable effect.  

\---

\#\# 5\. Mathematical Relations  
\- \*\*Induced voltage:\*\*    
  $$ V \\propto N \\cdot r^2 $$    
  where N \= turns, r \= coil radius.  

\- \*\*Power per band:\*\*    
  $$ P \\propto N^2 \\cdot r^4 $$  

\- \*\*Energy difference (A/B test):\*\*    
  $$ \\Delta P \= \\frac{P\_{RP9} \- P\_{BLANK}}{P\_{BLANK}} $$    
  typically \+30–60 %.  

\- \*\*Asymmetry source:\*\*    
  $$ C\_\\lambda(I) \= \\|\\,S\_\\lambda(H(I)) \- H(S\_\\lambda(I))\\,\\|\_2 \> 0 $$    
  shows that non-commutative transformations generate residual energy.  

\---

\#\# 6\. Philosophical Implication  
RP9 demonstrates that:  
\- Energy is a \*\*difference\*\*, not a substance.    
\- Friction between incompatible motions is the very source of motion.    
\- Geometry and observation are as important as matter in shaping reality.  

\---

\#\# 7\. Physical Anchor  
The planet’s rotation is an example:    
\- Earth’s axial tilt (23.4°) is an inherent asymmetry.    
\- It creates seasons, precession, magnetic fields – continuous energy.    
\- RP9 is the same principle in miniature, but artificially structured.  

\---

\#\# 8\. Practical Applications  
\- \*\*Small-scale:\*\* battery-free sensors, IoT    
\- \*\*Medium-scale:\*\* self-sustaining buildings    
\- \*\*Large-scale:\*\* architecture, art, installations    
\- \*\*Scientific:\*\* new experimental paths to understand primes, φ and π in physics  

\---

\#\# 9\. Conclusion  
RP9 works because asymmetry cannot be neutralized and inevitably generates motion in the field.    
The Three-Band Coil is the first practical way to demonstrate this in a clear, measurable form.  

This is not “free energy” in a mystical sense, but a release of latent potential that has always been present in the structure.

\---

Anton Wallin

\- \- \- \= ( 0 ) \= \- \- \-
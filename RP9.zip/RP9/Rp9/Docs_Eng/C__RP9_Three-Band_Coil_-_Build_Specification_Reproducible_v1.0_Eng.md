\# A Short Introduction to the RP9 Model

The RP9 coil is built on a unique principle in which energy is not created, but released from an existing potential.    
This potential arises from the tension between two incompatible motions: the \*\*linear\*\* (which tends toward infinite expansion) and the \*\*circular\*\* (which tends toward return and resonance).

\*\*Friction as an energy source:\*\*    
When linear and circular motion meet in perfect symmetry, there is no net effect.    
But when that symmetry is broken — for example, by rotating a pyramid — a “friction in the field” is created.    
This friction is a permanent imbalance that generates continuous motion.

\---

\# RP9 Three-Band Coil – Build Specification (Reproducible v1.0)

\*\*Anton Wallin – Resonance Point 9 (2025)\*\*

\---

\#\# 0\) Overview

\- \*\*Geometry:\*\* 3 pyramid frames: two aligned (axis), one rotated out of phase.    
\- \*\*Coil:\*\* air-core, circular, exact radius, turns, wire diameter and resistance.  

\*\*Three bands:\*\*

$$f\_1 \= 420 \\,\\text{Hz}$$    
$$f\_2 \= \\varphi \\cdot 420 \\,\\text{Hz} \\approx 680 \\,\\text{Hz}$$    
$$f\_3 \= \\varphi^2 \\cdot 420 \\,\\text{Hz} \\approx 1100 \\,\\text{Hz}$$  

where    
$$\\varphi \= \\frac{1 \+ \\sqrt{5}}{2} \\approx 1.618$$  

\- \*\*Wiring:\*\* series RLC per band, against load $R\_L \= 10\\,\\Omega$, measure $V\_\\text{RMS}$.    
\- \*\*Test:\*\* A/B (BLANK 0° vs RP9 12–15°), compute    
  $$\\Delta P \= \\frac{P\_\\text{RP9} \- P\_\\text{BLANK}}{P\_\\text{BLANK}}.$$

\---

\#\# 1\) Exact coil data (S2 baseline – room scale)

\- Coil form: single-layer circular air-core, cylindrical winding.    
\- Radius (to wire center): $r \= 0.200 \\,\\text{m}$ (diameter $0.400 \\,\\text{m}$).    
\- Axial winding width: $w \= 8 \\,\\text{mm}$ (tight single layer).    
\- Wire: enameled copper, diameter $0.63 \\,\\text{mm}$ (AWG22), resistivity $\\rho\_\\text{Cu} \= 1.68\\times10^{-8}\\,\\Omega\\cdot\\text{m}$.    
\- Turns: $N \= 400$ (counted, fixed).    
\- Wire length: $\\ell \\approx 400 \\cdot 2\\pi \\cdot 0.200 \\approx 503 \\,\\text{m}$.    
\- Wire area: $A \\approx 3.12\\times10^{-7}\\,\\text{m}^2$.    
\- Copper resistance: $R\_\\text{Cu} \\approx 27.1 \\,\\Omega$.  

\*\*Inductance (Wheeler-like log formula):\*\*

$$L \\approx \\mu\_0 N^2 r \\left\[ \\ln\\\!\\left(\\frac{8r}{a}\\right) \- 2 \\right\],$$    
with $a \= d/2 \= 0.315 \\,\\text{mm}$.

Result: $L \\approx 0.262 \\,\\text{H}$ (262 mH).

\> \*\*Fixed values S2:\*\* $L=0.262 \\,\\text{H}$, $R\_\\text{Cu}\\approx27.1 \\,\\Omega$, $N=400$, $r=0.200 \\,\\text{m}$, wire Ø0.63 mm.

\---

\#\# 2\) Exact capacitor values per band (S2)

Resonance formula:    
$$C \= \\frac{1}{(2\\pi f)^2 L}, \\quad L=0.262\\,\\text{H}.$$

\- \*\*Band 1 (420 Hz):\*\* $C\_1 \\approx 548 \\,nF$ → E12: 560 nF film cap.    
\- \*\*Band 2 (680 Hz):\*\* $C\_2 \\approx 213 \\,nF$ → E12: 220 nF film cap.    
\- \*\*Band 3 (1100 Hz):\*\* $C\_3 \\approx 81 \\,nF$ → E12: 82 nF film cap.  

\*\*Load resistor:\*\* $R\_L \= 10\\,\\Omega$, ≥10 W.

\---

\#\# 3\) Complete wiring diagram (ASCII)

Coil L \= 0.262 H, R\_Cu ≈ 27.1 Ω  
 o\~\~\~\~\~\~( L )\~\~\~\~\~\~o  
 | |  
 | \+-------------------\> BAND-SELECT  
 | |  
 | v  
 | \+-------------------------------+  
 | | BAND-SELECT (manual switch) |  
 | \+-------------------------------+  
 | | | |  
 | (BAND1) (BAND2) (BAND3)  
 | | | |  
 | \[C1\] \[C2\] \[C3\]  
 | 560 nF 220 nF 82 nF  
 | | | |  
 | \+-----------+-------------+------o----\[ R\_L \= 10 Ω \]----o  
 | ^ |  
 | | |  
 \+------------------------------------------------------------------+-------------+  
 Measure A Measure B

\---

\#\# 4\) Pyramid frames – exact S2 dimensions

\- Base: 40 × 40 cm    
\- Height: 65 cm (apex)    
\- Material: wood/PVC (non-metallic)  

Placement:    
\- Pyramids A & B aligned, 1.20 m apart.    
\- Pyramid C rotated 12° (RP9 state), BLANK \= 0°.    
\- Coil center \= in-center of apex triangle, plane ⟂ axis AB.

\---

\#\# 5\) Test protocol (A/B reproducible)

1\. Select band (C1, C2, C3).    
2\. BLANK: Pyramid C \= 0°, log $V\_\\text{RMS}$ for 10 min.    
3\. RP9: Pyramid C \= 12°, log again.    
4\. Compute power: $P \= V^2 / R\_L$.    
5\. Compute $\\Delta P$.    
6\. Rotate rig 90°/180° relative to north; repeat.    
7\. Repeat 3× per band.

\---

\#\# 6\) BOM – parts list (S2)

| Category  | Part         | Specification                          | Qty | Notes |  
|-----------|-------------|-----------------------------------------|-----|-------|  
| Coil      | Wire        | Cu Ø0.63 mm, N=400, length \~503 m       | 1   | AWG22 |  
| Coil form | Ring        | Ø400 mm slot 8 mm (plywood/acrylic)     | 1   | Non-metallic |  
| Caps      | C1          | 560 nF film cap, ≥250 VAC, ±5%          | 1   | 420 Hz |  
|           | C2          | 220 nF film cap, ≥250 VAC, ±5%          | 1   | 680 Hz |  
|           | C3          | 82 nF film cap, ≥250 VAC, ±5%           | 1   | 1100 Hz |  
| Load      | Resistor    | 10 Ω, ≥10 W                             | 1   | wirewound |  
| Switch    | Selector    | 3-pole rotary                           | 1   | band select |  
| Frames    | Pyramid     | 40×40 base, 65 cm height                | 3   | non-metallic |

\---

\#\# 7\) Scaling S3/S4

\- \*\*S3:\*\* r=0.60 m, N=800, wire Ø1.0 mm.    
\- \*\*S4:\*\* r=3.0 m, N=1600, wire Ø2–4 mm.  

Always recompute $L$ and $C\_i$.

\---

\#\# 8\) Data & Reporting

\- Power: $P \= V^2 / R\_L$.    
\- Delta: $\\Delta P \= (P\_\\text{RP9} \- P\_\\text{BLANK}) / P\_\\text{BLANK}$.    
\- Expected: \+30–60% in RP9 state.    
\- Log: CSV with timestamp, band, mode, V, angle, azimuth, temp, notes.

\---

\#\# 9\) FAQs

\- \*\*Free energy?\*\* No, RP9 extracts asymmetry.    
\- \*\*Why three bands?\*\* Robust resonance triplet.    
\- \*\*All bands at once?\*\* No, one at a time.    
\- \*\*Ferrite?\*\* Possible, but L changes drastically. Start with air-core.

\---

\#\# 10\) Summary – completeness

\- Coil: S2 values: $L=0.262$ H, $R≈27.1\\,\\Omega$, N=400, r=0.200 m, Ø0.63 mm.    
\- Caps: C1=560 nF, C2=220 nF, C3=82 nF.    
\- Circuit: wiring diagram \+ measurement points.    
\- Frames: 40×40 cm base, 65 cm height, RP9 rotation.    
\- Test: A/B with ΔP calculation.    
\- BOM: full list ready.    
\- Scaling: recipes for S3/S4.

\*\*Sufficient for third-party replication.\*\*

\---

\#\# License

CC BY 4.0 – Creative Commons Attribution 4.0 International    
Credit: Anton Wallin – RP9 – Resonance Point 9 (2025)

\---

Anton Wallin    
\- \- \- \= ( 0 ) \= \- \- \-


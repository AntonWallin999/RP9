# Docs_Eng

_Index updated: 2025-09-02T00:32:30_

## Documents
- [00__Rp9_Overview_Map_A-B-C-D.md](00__Rp9_Overview_Map_A-B-C-D.md)
- [A__RP9_The_Axiom_Model_eng.md](A__RP9_The_Axiom_Model_eng.md)
- [B__RP9_-_Theoretical_Foundation_for_the_Three-Band_Coil_Eng.md](B__RP9_-_Theoretical_Foundation_for_the_Three-Band_Coil_Eng.md)
- [C__RP9_Three-Band_Coil_-_Build_Specification_Reproducible_v1.0_Eng.md](C__RP9_Three-Band_Coil_-_Build_Specification_Reproducible_v1.0_Eng.md)
- [D__RP9_Three-Band_Coil_-_Open_Research_Eng.md](D__RP9_Three-Band_Coil_-_Open_Research_Eng.md)


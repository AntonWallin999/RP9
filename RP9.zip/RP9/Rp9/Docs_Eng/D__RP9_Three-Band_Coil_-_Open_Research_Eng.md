\# RP9 Three-Band Coil – Open Research    
Anton Wallin – Resonance Point 9 (2025)

\---

\#\# Contents  
1\. \[README\](#readme)    
2\. \[MANIFEST\](#manifest)    
3\. \[VALUE\_COMPASS\](#value-compass)    
4\. \[TEST\_GUIDE\](#test-guide)    
5\. \[WHITEPAPER\](#whitepaper)    
6\. \[LICENSE\](#license)    
7\. \[ASSETS\](#assets)  

\---

\#\# README  
The RP9 Three-Band Coil is an open construction. It is based on the \*\*RP9 model\*\*, where energy is released from the friction between symmetry and asymmetry.    
This repository is a complete package including manifesto, compass, test guide, whitepaper and license for free use.  

The goal: to demonstrate that energy is not created from nothing, but released from latent potential in geometric asymmetry.  

\---

\#\# MANIFEST  
\#\#\# Introduction  
RP9 (Resonance Point 9\) is the point where linear and circular motion meet without resolution.    
This creates a self-stabilizing friction that can be manifested in a coil.  

\#\#\# Principle  
\- Two pyramids aligned \= symmetry \= no net effect.    
\- A third pyramid rotated 9–15° creates imbalance → field dissonance.    
\- A coil placed at the center captures this energy as electrical output.  

\#\#\# Frequency Dimension  
The coil is tuned to three resonance bands:    
\- f₁ \= 420 Hz    
\- f₂ \= φ·420 Hz ≈ 680 Hz    
\- f₃ \= φ²·420 Hz ≈ 1100 Hz  

ΔP ≈ \+30–60 % compared to blank state.  

\#\#\# Conclusion  
RP9 is not “free energy,” but the release of latent potential through asymmetric geometry.  

\---

\#\# VALUE\_COMPASS  
\#\#\# Scale S2 – Room  
\- Radius ≈ 0.20 m, N≈400    
\- Output: µW    
\- Sufficient for: LED blink, logging  

\#\#\# Scale S3 – Building  
\- Radius ≈ 0.60 m, N≈800    
\- Output: mW    
\- Sufficient for: sensors, IoT  

\#\#\# Scale S4 – Site  
\- Radius ≈ 3.0 m, N≈1600    
\- Output: tens of W    
\- Sufficient for: lamps, installations  

\#\#\# Recommended Path  
1\. Start with S2 for demonstration    
2\. Scale to S3 for practical use    
3\. Build S4 when community is ready  

\---

\#\# TEST\_GUIDE  
\#\#\# Purpose  
To demonstrate the RP9 effect by comparing symmetric (BLANK) vs asymmetric (RP9) states.  

\#\#\# Equipment  
\- Coil (air-core)    
\- Three capacitor branches (420 Hz, φ·420 Hz, φ²·420 Hz)    
\- Load resistor (10 Ω)    
\- Multimeter or logger    
\- Three pyramid frames  

\#\#\# Procedure  
1\. Place coil at the center.    
2\. BLANK: third pyramid at 0°. Log V\_RMS for 10 min.    
3\. RP9: third pyramid at 12–15°. Log for 10 min.    
4\. Compute P \= V²/R.    
5\. ΔP \= (P\_RP9 – P\_BLANK) / P\_BLANK.    
6\. Repeat across three bands.  

\#\#\# Expected Result  
ΔP ≈ \+30–60 %. The effect is additive across bands.  

\---

\#\# WHITEPAPER  
\#\#\# 1\. Background  
Energy has traditionally been seen as something generated. RP9 shows that energy already exists and is released from geometric friction.  

\#\#\# 2\. RP9 Principle  
\- RP9 \= node between φ and √2    
\- Friction between linear and circular    
\- Energy released when symmetry is broken  

\#\#\# 3\. Geometry  
\- Two pyramids aligned \= symmetry    
\- Third pyramid rotated \= imbalance    
\- Field circulation emerges  

\#\#\# 4\. The Three-Band Coil  
\- Three bands (420, 680, 1100 Hz)    
\- Coil \+ capacitor branches \+ load    
\- Additive effect  

\#\#\# 5\. Simulations  
\- V ∝ N·r²    
\- P ∝ N²·r⁴    
\- ΔP \+30–60 % (S2–S4)  

\#\#\# 6\. Value Compass  
\- S2: µW (demo)    
\- S3: mW (utility)    
\- S4: W (installations)  

\#\#\# 7\. Field Test  
A/B test between BLANK and RP9.    
ΔP \> 0 confirms RP9 effect.  

\#\#\# 8\. Applications  
\- Technical: sensors, IoT    
\- Scientific: new physical model    
\- Philosophical: energy \= difference    
\- Practical: architecture & art  

\#\#\# 9\. Conclusion  
The RP9 Three-Band Coil shows that energy exists in the friction of symmetry.    
This is not “free energy” – it is nature’s own latent potential made measurable.  

\---

\#\# LICENSE  
Creative Commons Attribution 4.0 International (CC BY 4.0)  

You are free to use, share, and modify this material,    
as long as you credit: Anton Wallin – RP9 – Resonance Point 9 (2025).  

\---

\#\# ASSETS  
This section is for diagrams, illustrations and sketches.    
Examples:    
\- ASCII diagram of pyramids    
\- Simple wiring schematic    
\- Frequency curves

\---

Anton Wallin

\- \- \- \= ( 0 ) \= \- \- \-


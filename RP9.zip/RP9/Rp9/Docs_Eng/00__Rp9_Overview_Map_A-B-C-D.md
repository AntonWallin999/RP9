\# Overview Map A-B-C-D

Here is an overview of how the four documents work together:

\---

\#\# A complete and functional documentation package

\#\#\# A: Axiom – The RP9 Model (The Axiom)    
\*\*1:\*\* It introduces the project with logical fundamental principles that establish a unique philosophical framework before the technical details are presented.

\---

\#\#\# D: RP9 Three-Band Coil – Open Research (The Overview)    
\*\*2:\*\* This is an introduction and "landing page" for the project.    
It provides a quick overview of the RP9 Manifesto, its purpose, the triple-frequency principle, the test guide, and a summary of the whitepaper.    
It is ideal for those who want to quickly understand the concept at a high level.

\---

\#\#\# B: RP9 – Theoretical Foundation for the Three-Band Coil (The Theory)    
\*\*3:\*\* Here is the in-depth theoretical explanation.    
The document explains the fundamental principles, the nature of friction, mathematical relationships, and the philosophical implications.    
It gives the reader the intellectual foundation to understand \*why\* the RP9 model works, not just \*how\*.

\---

\#\#\# C: RP9 Three-Band Coil – Build Specification (The Manual)    
\*\*4:\*\* This document is the practical core of the package.    
It contains all previously missing information for reproduction, such as exact coil dimensions, component values for capacitors, a circuit diagram, and a step-by-step test guide.    
This document is crucial for a third party to be able to replicate the experiment.

\---

\*\*Enjoy\*\*

Anton Wallin  

\- \- \- \= ( 0 ) \= \- \- \-


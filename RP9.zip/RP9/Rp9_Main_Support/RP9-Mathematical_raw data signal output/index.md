# RP9-Mathematical

_Index updated: 2025-09-02T00:32:30_

## Folders
- [csv](csv/)
- [html](html/)
- [json](json/)
- [PNG](PNG/)

## Other files
- desktop.ini


# PNG

_Index updated: 2025-09-02T00:32:30_

## Other files
- rp9_B_36.png
- rp9_B_field.png
- rp9_coil_voltage.png
- rp9_V_36.png


# The Cycle of Gravitation (G-Cycle)

---

## 1. Introduction
Gravitation is not understood here as a force in the classical sense, but as an **inverted phase relation in the information field**.  
While prime numbers represent extroverted nodes (expansion and separation), gravitation represents introverted phase binding (cohesion and feedback).  

---

## 2. Numerical Duality
The system is divided into two structures:

- **Prime nodes:** 3, 7, 11, 13 … → extroverted expansion.  
- **Gravitational nodes:** 2, 5, 8, 10 … → introverted cohesion.  

Together these form a complementary structure driving fractal stability.

---

## 3. Phase Structure of the G-Cycle
The cycle is written over the interval 0–10.  
- 6 visible cycles (0–10 repeated).  
- 7th cycle = **primary cycle** (fundamental feedback node).  

Gravitation is expressed as a phase-shifted sine function:
$$
G(t) = \sin(\omega t + \pi) + \sum_{n=2}^\infty a_n \cos(n \omega t)
$$

Here $\pi$ provides phase inversion, and the overtones $a_n$ describe multiple levels of gravitation.

---

## 4. Relation to the Speed of Light and α
Gravitation and the speed of light are bound in the same cycle:  
- Light = extroverted motion (maximum expansion).  
- Gravitation = introverted phase (maximum cohesion).  

The fine-structure constant $\alpha \approx 1/137$ acts as the regulating scaling factor.  
Balance occurs when:
$$
c \cdot \alpha \approx RP9
$$

---

## 5. RP9 and the G-Cycle
RP9 ≈ 0.27856 functions as a disharmonic phase node.  
The gravitation cycle (G9) is its inverted mirror.  

- RP9 = centrifugal (outward).  
- G9 = centripetal (inward).  

Together they stabilize the information field.

---

## 6. Applications
- **Prime distribution:** gravitation balances asymmetry.  
- **Cosmology:** galactic rotations and expansion → governed by the inversion of the G-cycle.  
- **Energy and matter:** phase shift between RP9 and G9 explains stability.  

---

## 7. Conclusion
The cycle of gravitation is an **inverted phase node** that complements RP9.  
It serves as a code for feedback, where expansion and separation (primes, RP9) are balanced by cohesion and inversion (gravitation, G9).  
Together they create a self-stabilizing fractal cycle.

---
**Författare:** Anton Wallin  
− = ( o ) = −
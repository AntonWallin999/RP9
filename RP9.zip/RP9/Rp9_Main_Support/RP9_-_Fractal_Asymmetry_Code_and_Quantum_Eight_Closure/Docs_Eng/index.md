# Docs_Eng

_Index updated: 2025-09-02T00:32:30_

## Documents
- [Core_Formalization_-_Fractal_Millennium_Framework__Eng.md](Core_Formalization_-_Fractal_Millennium_Framework__Eng.md)
- [RP9_-_Fractal_Asymmetry_Code_and_the_Closure_of_the_Quantum_Eight_Eng.md](RP9_-_Fractal_Asymmetry_Code_and_the_Closure_of_the_Quantum_Eight_Eng.md)

